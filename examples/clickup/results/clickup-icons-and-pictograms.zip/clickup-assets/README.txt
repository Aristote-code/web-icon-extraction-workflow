ClickUp extraction, 15 October 2026
Open coverage-report.html for findings and limits; gallery.html to browse and download.
svg/: normalized standalone exports. incomplete-svg/: missing local definitions.
originals/: exact downloaded files, including original sprite map and auxiliary images.
raw-symbols/ and raw-inline/: extracted unnormalized geometry.
manifest.json: hashes, provenance, symbol IDs, source types, verification.
coverage.json: captured states. download-failures.json: failed requests and recovery flags.
The extraction does not establish ownership or a license to reuse these assets.
